export interface Classroom {
  id?: number,
  name?: string
}
