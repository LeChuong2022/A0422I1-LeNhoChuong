package com.codegym.demo_a04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoA04Application {

    public static void main(String[] args) {
        SpringApplication.run(DemoA04Application.class, args);
    }

}
